package looneytrojans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConectarBaseDatos {
    // Atributos para la conexión
    static String url = "jdbc:mysql://localhost:3306/looney_troyans"; // Nombre de la base de datos
    static String user = "root";  // Usuario de la base de datos
    static String pass = "angri95a";  // Contraseña del usuario
    
    // Método para realizar la conexión
    public static Connection getConexion() {
        Connection con = null;
        
        try {
            // Establecemos la conexión
            con = DriverManager.getConnection(url, user, pass);
            System.out.println("Conexión exitosa");
        } catch (SQLException e) {
            e.printStackTrace();  // Si falla la conexión, mostramos el error
        }
        
        return con;  // Devolvemos la conexión
    }
}