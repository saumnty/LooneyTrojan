package looneytrojans;

import java.io.File;
import java.sql.*;

public class ManejoBaseDatos {

    // Insertar un nuevo usuario
    public static boolean insertarUsuario(String nombre, String email, String contraseña, int idPlan) {
        if (nombre.isEmpty() || email.isEmpty() || contraseña.isEmpty()) {
            System.out.println("Los campos no pueden estar vacíos.");
            return false;
        }

        if (verificarEmailExistente(email)) {
            System.out.println("El correo ya está registrado.");
            return false;
        }

        String sql = "INSERT INTO usuarios (nombre, email, contraseña, id_plan) VALUES (?, ?, ?, ?)";

        try (Connection con = ConectarBaseDatos.getConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, email);
            stmt.setString(3, contraseña);
            stmt.setInt(4, idPlan);

            int filasInsertadas = stmt.executeUpdate();
            return filasInsertadas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Consultar todos los usuarios
    public static void consultarDatos() {
        String query = "SELECT * FROM usuarios";

        try (Connection con = ConectarBaseDatos.getConexion();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Nombre: " + rs.getString("nombre"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Contraseña: " + rs.getString("contraseña"));
                System.out.println("Estado: " + rs.getString("estado"));
                System.out.println("ID Plan: " + rs.getInt("id_plan"));
                System.out.println("---");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Verificar si un email ya está registrado
    private static boolean verificarEmailExistente(String email) {
        String query = "SELECT * FROM usuarios WHERE email = ?";

        try (Connection con = ConectarBaseDatos.getConexion();
             PreparedStatement stmt = con.prepareStatement(query)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            return rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Actualizar datos de un usuario
    public static boolean actualizarUsuario(int id, String nombre, String email, String contraseña, int idPlan) {
        if (nombre.isEmpty() || email.isEmpty() || contraseña.isEmpty()) {
            System.out.println("Los campos no pueden estar vacíos.");
            return false;
        }

        String sql = "UPDATE usuarios SET nombre = ?, email = ?, contraseña = ?, id_plan = ? WHERE id = ?";

        try (Connection con = ConectarBaseDatos.getConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, email);
            stmt.setString(3, contraseña);
            stmt.setInt(4, idPlan);
            stmt.setInt(5, id);

            int filasActualizadas = stmt.executeUpdate();
            return filasActualizadas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Eliminar usuario
    public static boolean eliminarUsuario(int id) {
        String sql = "DELETE FROM usuarios WHERE id = ?";

        try (Connection con = ConectarBaseDatos.getConexion();
             PreparedStatement stmt = con.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int filasEliminadas = stmt.executeUpdate();

            return filasEliminadas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Método para verificar si un archivo está en el diccionario de virus
    public static boolean verificarVirus(String nombreArchivo) {
        String sql = "SELECT * FROM diccionario_virus WHERE nombre_archivo = ?";
        
        try (Connection con = ConectarBaseDatos.getConexion();  
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setString(1, nombreArchivo);  
            ResultSet rs = stmt.executeQuery();

            return rs.next();  // Si existe el archivo, significa que es un virus
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para eliminar un archivo
    public static boolean eliminarArchivo(String rutaArchivo) {
        File archivo = new File(rutaArchivo);
        if (archivo.exists()) {
            return archivo.delete();  // Elimina el archivo
        }
        return false;
    }

    // Método para mover el archivo a cuarentena
    public static boolean moverAcuarentena(String rutaArchivo) {
        File archivo = new File(rutaArchivo);
    
        if (archivo.exists()) {
            // Ruta de la carpeta de cuarentena
            String rutaCuarentena = "C:/ruta/a/la/cuarentena/";

            // Crear la carpeta de cuarentena si no existe
            File carpetaCuarentena = new File(rutaCuarentena);
            if (!carpetaCuarentena.exists()) {
                boolean creada = carpetaCuarentena.mkdirs(); // Crea todos los directorios necesarios
                if (!creada) {
                    System.out.println("No se pudo crear la carpeta de cuarentena.");
                    return false;
                }
            }

            // Mover el archivo a la carpeta de cuarentena
            File cuarentena = new File(rutaCuarentena + archivo.getName());
            return archivo.renameTo(cuarentena);  // Mueve el archivo a la carpeta cuarentena
        }
        return false;
    }
    
    // Método para cargar todas las líneas de un archivo .txt a la tabla diccionario_virus
    public static void cargarDiccionarioDesdeArchivo(String rutaArchivo) {
        File archivo = new File(rutaArchivo);

        if (!archivo.exists()) {
            System.out.println("El archivo no existe: " + rutaArchivo);
            return;
        }

        try (Connection con = ConectarBaseDatos.getConexion();
             PreparedStatement verificar = con.prepareStatement(
                 "SELECT COUNT(*) FROM diccionario_virus WHERE nombre_archivo = ?");
             PreparedStatement insertar = con.prepareStatement(
                 "INSERT INTO diccionario_virus (nombre_archivo) VALUES (?)");
             java.util.Scanner scanner = new java.util.Scanner(archivo, "UTF-8")) {

            int insertados = 0;
            int duplicados = 0;

            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine().trim();

                if (!linea.isEmpty()) {
                    // Verifica si ya existe
                    verificar.setString(1, linea);
                    ResultSet rs = verificar.executeQuery();
                    rs.next();
                    if (rs.getInt(1) == 0) {
                        insertar.setString(1, linea);
                        insertar.addBatch();
                        insertados++;
                    } else {
                        duplicados++;
                    }
                }
            }

            insertar.executeBatch();
            System.out.println("Carga completa. Insertados: " + insertados + ", Duplicados: " + duplicados);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error al cargar el diccionario.");
        }
    }
}